var express = require('express');
var router = express.Router();
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');




/* GET todo page. */
router.get('/:id', function(req, res) {
  const url = 'mongodb://localhost:27017';
  const dbName = 'employeedb';
  let index = req.params.id;

(async function() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log("Connected correctly to server");

    const db = client.db(dbName);
    const todoList = await db.collection('todo').find().toArray()
    res.render('todoList', { todo : todoList[index]});
  } catch (err) {
    console.log(err.stack);
  }
  
  client.close();
})();
          
  });

module.exports = router;
