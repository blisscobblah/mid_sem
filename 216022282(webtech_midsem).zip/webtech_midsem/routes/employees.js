var express = require('express');
var router = express.Router();
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');



const data = [
  {
    name: 'Vicent Adomako',
    department: 'Accounts',
    todo: [{task:'Prepare sales report',
    complete: false},{task: 'Prepare budget',complete: false}]
  },
  {
    name: 'John Mahamma',
    department: 'marketing',
    todo: [{task:'start marketing campaign',
    complete: false},{task: 'finish annual budget',complete: false}]
  },
  {
    name: ' Lucy Adegah',
    department: 'HR',
    todo: [{task:'Prepare quarterly report',
    complete: false},{task: 'Prepare budget',complete: false}]
  },
  {
    name: 'Liben Tetteh',
    department: 'IT',
    todo: [{task:'Set up restore point',
    complete: false},{task: 'perform network security check',complete: false}]
  }
]


/* GET employees page. */
router.get('/', function(req, res) {

  const url = 'mongodb://localhost:27017';
  const dbName = 'employeedb';

(async function() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log("Connected correctly to server");

    const db = client.db(dbName);

    // Insert some data
    let r;
    r = await db.collection('todo').insertMany(data);
    assert.equal(data.length, r.insertedCount);

    const staffList = await db.collection('todo').find().toArray()
    res.render('staffList', { title: 'Employees', staffList });
  } catch (err) {
    console.log(err.stack);
  }
  // await client.db(dbName).dropDatabase();
  // Close connection
  client.close();
})();
    
    
});

module.exports = router;
